import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verifyrequests',
  templateUrl: './verifyrequests.component.html',
  styleUrls: ['./verifyrequests.component.css']
})
export class VerifyrequestsComponent implements OnInit {

  email:String;
  mobile:String;
  constructor() { }

  ngOnInit() {
  }

  onLogin(){}
  btnClick(){}
  
  
}
