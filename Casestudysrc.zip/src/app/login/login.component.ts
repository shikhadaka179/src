import {BankadminserviceService} from '../bankadminservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {NgModule} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [BankadminserviceService]
})
export class LoginComponent implements OnInit {

  constructor(private iServe: BankadminserviceService, private router: Router) {}
  userName: String;
  password: String;

  httpdata: any[];

  onLogin(form: NgForm) {

    this.httpdata = this.iServe.alogin(this.userName, this.password);
    if (this.httpdata != null) {
      let sta = this.httpdata[0]["status"];
      if (sta == "Login Success") {
        this.router.navigateByUrl('/afteradminlogin');
      } else {
        console.log(this.httpdata);
      }
    }

    //    this.http.get('http://localhost:8080nalCase/rest/adminserve/alogin')

    // if (form.valid) {
    //  console.log(form.value);
    // this.iServe.regDonor(this.name, this.username, this.password, this.email, this.dob, this.gender, this.bloodgroup, this.weight, this.mobile, this.address, this.state, this.city);
    //  }
  }

  ngOnInit() {
  }

  //btnClick = function() {

  //this.router.navigateByUrl('/afteradminlogin');
  //  };

}
